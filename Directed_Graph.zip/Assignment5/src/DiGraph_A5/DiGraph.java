package DiGraph_A5;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.concurrent.ConcurrentHashMap;


public class DiGraph implements DiGraph_Interface {

	ConcurrentHashMap<String, Vertex> map = new ConcurrentHashMap<String, Vertex>();
	HashSet<Long> vertSet = new HashSet<Long>();
	ConcurrentHashMap<Long, Edge> edgeSet = new ConcurrentHashMap<Long, Edge>();

	// in here go all your data and methods for the graph
	// and the topo sort operation

	public DiGraph ( ) { // default constructor
		// explicitly include this
		// we need to have the default constructor
		// if you then write others, this one will still be there
	}

	@Override
	public boolean addNode(long idNum, String label) {
		if(idNum < 0){
			return false;
		}else{
			Vertex v = new Vertex(idNum, label);
			if(map.keySet().contains(label) || vertSet.contains(idNum)){
				return false;
			}
			vertSet.add(idNum);
			map.put(label, v);
			return true;
		}
	}

	@Override
	public boolean addEdge(long idNum, String sLabel, String dLabel, long weight, String eLabel) {


		if(idNum < 0){
			return false;
		}
		Edge e = new Edge(idNum, sLabel, dLabel, weight);


		if(edgeSet.keySet().contains(idNum)){
			return false;
		}

		if(map.keySet().contains(sLabel) && map.keySet().contains(dLabel)){
			if(map.get(sLabel).outEdgeList.contains(dLabel)){
				return false;
			}
			map.get(sLabel).outEdgeList.add(dLabel);
			map.get(dLabel).inEdgesList.add(sLabel);
		}else{
			return false;
		}

		edgeSet.put(idNum, e);
		return true;
	}


	@Override
	public boolean delNode(String label) {
		Boolean b = false;

		if(map.keySet().contains(label)){
			for(String s : map.get(label).outEdgeList){
				map.get(s).inEdgesList.remove(label);

			}
			b = true;
		}

		if(b){
			vertSet.remove(map.get(label).id);
			map.remove(label);
		}
		return b;
	}

	@Override
	public boolean delEdge(String sLabel, String dLabel) {
		Boolean b = false;
		Edge edg = null;		

		if(map.keySet().contains(sLabel) && map.keySet().contains(dLabel)){
			if(map.get(sLabel).outEdgeList.contains(dLabel) && map.get(dLabel).inEdgesList.contains(sLabel)){
				map.get(sLabel).outEdgeList.remove(dLabel);
				map.get(dLabel).inEdgesList.remove(sLabel);

				b = true;
			}
		}

		if(b){
			for(Edge ed : edgeSet.values()){
				if (ed.slabel == sLabel && ed.dlabel == dLabel){
					edg = ed;
				}
			}
			edgeSet.remove(edg.id);
		}

		return b;
	}

	@Override
	public long numNodes() {

		return vertSet.size();
	}

	@Override
	public long numEdges() {

		return edgeSet.size();
	}

	@Override
	public String[] topoSort() {
		String[] topoSortArray = new String[vertSet.size()];
		Deque<Vertex> q = new ArrayDeque<Vertex>();
		int x = 0;
		HashSet<String> out = new HashSet<String>();
		for(String s : map.keySet()){
			if(map.get(s).inEdgesList.size() == 0){
				q.add(map.get(s));
			}

		}

		while(!map.isEmpty()){
			if(q.isEmpty()){
				topoSortArray = null;
				break;
			}
			while (!q.isEmpty()){

				topoSortArray[x] = q.getFirst().label;
				out = map.get(topoSortArray[x]).outEdgeList;
				this.delNode(topoSortArray[x]);
				x++;
				q.removeFirst();
				for(String s : out){
					if(map.get(s).inEdgesList.size() == 0){
						q.add(map.get(s));
					}
				}

			}

		}
		return topoSortArray;
	}

	// rest of your code to implement the various operations
}