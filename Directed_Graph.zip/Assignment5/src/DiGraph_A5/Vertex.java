package DiGraph_A5;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class Vertex {

	 String label;
	 Vertex v;
	 long id;
	 int inEdges;
	 HashSet<String> outEdgeList;
	 HashSet<String> inEdgesList;
	 
	
	public Vertex(Long idnum, String Label){
		label = Label;
		id = idnum;
		v = this;
		inEdges = 0;
		outEdgeList = new HashSet<String>();
		inEdgesList = new HashSet<String>();
	}
	
	public String getLabel(){
		return label;
	}
	
	public Long getIDnum(){
		return id;
	}
	
}
