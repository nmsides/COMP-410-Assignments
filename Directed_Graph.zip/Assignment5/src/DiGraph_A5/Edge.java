package DiGraph_A5;

public class Edge {

	 long id;
	 String slabel;
	 String dlabel;
	 long weight;
	
	public Edge(long idNum, String sLabel, String dLabel){
		id = idNum;
		slabel = sLabel;
		dlabel = dLabel;
		weight = 1;
	}
	
	public Edge(long idNum, String sLabel, String dLabel, long Weight){
		id = idNum;
		slabel = sLabel;
		dlabel = dLabel;
		weight = Weight;
	}
	
	public long getID(){
		return id;
	}
	public String getsLabel(){
		return slabel;
	}
	public String getdLabel(){
		return dlabel;
	}
	public long getWeight(){
		return weight;
	}
	public long setWeight(long l){
		weight = l;
		return weight;
	}
}
