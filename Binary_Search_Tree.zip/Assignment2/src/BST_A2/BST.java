package BST_A2;

public class BST implements BST_Interface {
	public BST_Node root;
	int size;

	public BST(){ size=0; root=null; }

	@Override
	//used for testing, please leave as is
	public BST_Node getRoot(){ return root; }


	public boolean insert(String s) {
		if(size == 0){
			root = new BST_Node(s);
			root.left = null;
			root.right = null;
			size++;
			return true;
		}else if(s != null){
			root.insertNode(s);
			size++;
			return true;
		}
		return false;
	}

	@Override
	public boolean remove(String s) {
		if(size == 0) {
			return false;
		}
		if(size == 1){
			root = null;
			size--;
			return false;
		}
		if(root.left!=null && root.right == null && root.data.equals(s)){//sets root as next left node if no nodes on right.
			root = root.left;
			size--;
			return true;
		}
		if(!root.containsNode(s))return false;
		if(root != null){
			root.removeNode(s, this.root);
			size--;
			return true;
		}


		return false;
	}

	@Override
	public String findMin() {
		if(size ==0) return null;
		if(size ==1) return root.data;
		return root.findMin().data;
	}

	@Override
	public String findMax() {
		if(size ==0) return null;
		if(size==1) return root.data;
		return root.findMax().data;
	}

	@Override
	public boolean empty() {
		if(size == 0) return true;
		return false;
	}

	@Override
	public boolean contains(String s) {
		BST_Node x = root;
		if(size == 0){
			return false;
		}else if(x.containsNode(s)){
			return true;
		}
		return false;
	}

	@Override
	public int size() {
		return size;
	}

	@Override
	public int height() {
		if(root == null) return -1;
		return root.getHeight()-1;
	}

}