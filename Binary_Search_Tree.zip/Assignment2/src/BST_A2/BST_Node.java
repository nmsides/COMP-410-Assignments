package BST_A2;

public class BST_Node {
	String data;
	BST_Node left;
	BST_Node right;

	BST_Node(String data){ this.data=data; }

	// --- used for testing  ----------------------------------------------
	//
	// leave these 3 methods in, as is

	public String getData(){ return data; }
	public BST_Node getLeft(){ return left; }
	public BST_Node getRight(){ return right; }

	// --- end used for testing -------------------------------------------


	// --- fill in these methods ------------------------------------------
	//
	// at the moment, they are stubs returning false 
	// or some appropriate "fake" value
	//
	// you make them work properly
	// add the meat of correct implementation logic to them

	// you MAY change the signatures if you wish...
	// make the take more or different parameters
	// have them return different types
	//
	// you may use recursive or iterative implementations


	public boolean containsNode(String s){ 
		if(s.compareTo(this.data)  == 0) return true;
		if(s.compareTo(this.data) < 0 && this.left != null && this.left.containsNode(s)) return true;
		if(s.compareTo(this.data) > 0 && this.right != null && this.right.containsNode(s)) return true;
		return false;
	}

	public boolean insertNode(String s){ 
		BST_Node n = new BST_Node(s);
		BST_Node x = this;

		if(s.compareTo(x.getData()) < 0){
			if(x.left == null){
				x.left = n;

				return true;
			}else {
				x.left.insertNode(s);

			}
		}else if(s.compareTo(x.getData()) > 0){
			if(x.right == null){
				x.right = n;

				return true;
			}else{
				x.right.insertNode(s);

			}
		}
		return false;
	}
	public boolean removeNode(String s, BST_Node x){ 
		if (s.compareTo(this.data) < 0) {//compares s to root data, enters loop if less than
			if (left != null)//checks if left is valid
				return left.removeNode(s, this);//recursion
			else
				return false;
		} else if (s.compareTo(this.data) > 0) {//enters loop is greater than
			if (right != null)
				return right.removeNode(s, this);
			else{
				return false;
			}
		} else {
			if (left != null && right != null) {//if left and right are not null
				this.data = right.findMin().data;//sets minimum on right side as root
				right.removeNode(this.data, this);
			} else if(left==null && right != null){//if only values on right
				this.data = right.findMin().data;//minimum is now root
				right.removeNode(this.data, this);

			}else if (x.left == this) {//checks x.left to this
				x.left = (left != null) ? left : right;//will make end leaf
			} else if (x.right == this) {//checks x.right to this
				x.right = (left != null) ? left : right;// end leaf
			}
			return true;
		}
	}



	public BST_Node findMin(){ 
		BST_Node x = this;
		if(x.left == null){
			return x;
		}
		return x.left.findMin();
	}
	public BST_Node findMax(){ 
		BST_Node x = this;
		if(x != null){
			while(x.right!= null){
				x = x.right;
			}
		}
		return x; 
	}

	public int getHeight(){ 
		int lheight = 0;
		int rheight = 0;
		if(this.left != null){
			lheight = this.left.getHeight();
		}
		if(this.right!=null){
			rheight = this.right.getHeight();
		}
		if(lheight > rheight){
			return lheight+1;
		}else{
			return rheight+1;
		}
	}




	// --- end fill in these methods --------------------------------------


	// --------------------------------------------------------------------
	// you may add any other methods you want to get the job done
	// --------------------------------------------------------------------

	public String toString(){
		return "Data: "+this.data+", Left: "+((this.left!=null)?left.data:"null")
				+",Right: "+((this.right!=null)?right.data:"null");
	}
}