package LinkedList_A1;

public class LinkedListImpl implements LIST_Interface {
	Node sentinel; //this will be the entry point to your linked list (the head)
	private int numElts;

	public LinkedListImpl(){
		sentinel=new Node(0);
		numElts = 0;
	}



	public Node getRoot(){ 
		return sentinel;
	}

	public boolean insert(double elt, int index) {
		Node n = new Node(elt);
		
		if (index < 0 || index > numElts) return false;
		
		if (numElts == 0){
			sentinel.next = n;
			sentinel.prev = n;
			n.next = sentinel;
			n.prev = sentinel;
	
		}else {
			if(index == 0){
				n.next = selectNode(index);
				n.prev = sentinel;
				selectNode(index).prev = n;
				sentinel.next = n;
			}else{
				n.prev = selectNode(index-1);
				n.next = selectNode(index);
				selectNode(index-1).next = n;
				selectNode(index+1).prev = n;
			}
		}
		numElts++;
		return true;
	}

	public boolean remove(int index) {
	
		if (index < 0 || index > numElts) return false;
		
		if(numElts == 1){
			sentinel.next = sentinel;
			sentinel.prev = sentinel;
			} else{
				if(index ==0){
					selectNode(index+1).prev = sentinel;
					sentinel.next = selectNode(index+1);
			}else{
				selectNode(index+1).prev = selectNode(index-1);
				selectNode(index-1).next = selectNode(index+1);
			}
		}
		numElts--;
		return true;
	}

	public double get(int index) {
		if(index <0 || index > numElts || numElts ==0){
			return Double.NaN;
		}
		return selectNode(index).getData();
		
	}

	public int size() {
		return numElts;
	}

	public boolean isEmpty() {
		boolean b = false;
		if(numElts == 0){
			b = true;
		}
		return b;
	}

	public void clear() {
		sentinel.next = sentinel;
		sentinel.prev = sentinel;
		numElts = 0;

	}
	public Node selectNode(int index){
		Node select = sentinel.next;
		
		for (int i = 0; i < index; i++){
			select = select.next;
		}
		return select;	
	}
}
