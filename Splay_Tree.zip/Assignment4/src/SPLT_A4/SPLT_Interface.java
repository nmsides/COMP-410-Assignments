package SPLT_A4;
public interface SPLT_Interface {//It was me
	  public void insert(String s);
	  public void remove(String s);
	  public String findMin();
	  public String findMax();
	  public boolean empty();
	  public boolean contains(String s);
	  public int size();
	  public int height();
	  public SPLT_Node getRoot(); //DIO
}
