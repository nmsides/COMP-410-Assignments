package SPLT_A4;

public class SPLT implements SPLT_Interface{
	private SPLT_Node root;
	public int size;


	public SPLT() {
		this.size = 0;
	} 

	public SPLT_Node getRoot() { 
		return root;
	}  

	public void splay(SPLT_Node b) {
		while (b.parent != null) {
			SPLT_Node parent = b.parent; 
			SPLT_Node gparent = parent.parent; 

			//If parent is the root 
			if (gparent == null) {
				//b is on the left side 
				if (parent.left == b) {
					rotateRight(parent); //Make one rotation to the right
				}
				//b is on the right side
				else if (parent.right == b) {
					rotateLeft(parent);
				}
			}

			//If parent is lower than root 
			if (gparent != null) {
				//parent is on the left 
				if (gparent.left == parent) {
					//b is on the left of parent (same side)
					if (parent.left == b) {
						rotateRight(gparent); 
						rotateRight(parent); 
					}
					//b is on the right of parent (other side) 
					else if (parent.right == b) {
						rotateLeft(parent);
						rotateRight(gparent);
					}
				}
				//parent is on the right
				else if (gparent.right == parent) {
					//b is on the left instead 
					if (parent.left == b) {
						rotateRight(parent);
						rotateLeft(gparent);
					}
					//b is on the right also
					else if (parent.right == b) {
						rotateLeft(gparent); 
						rotateLeft(parent); 
					}
				}
			}
		}
		root = b; 
	}

	public void rotateRight(SPLT_Node n) {

		SPLT_Node lchild = n.left; 

		if (lchild != null) {
			n.left = lchild.right;  
			if (lchild.right != null) {
				lchild.right.parent = n; 
			}
			lchild.parent = n.parent; 
		}

		if (n.parent == null) {
			n.parent = lchild; 
		}
		else if (n == n.parent.left){
			n.parent.left = lchild; 
		}
		else {
			n.parent.right = lchild; 
		}

		if (lchild != null) {
			lchild.right = n; 
		}

		n.parent = lchild; 


	}
	public void rotateLeft(SPLT_Node n) {

		SPLT_Node rchild = n.right; 

		if (rchild != null) {
			n.right = rchild.left; 
			if (rchild.left != null) {
				rchild.left.parent = n; 
			}
			rchild.parent = n.parent;
		}

		//If n is the root, make rchild the new root 
		if (n.parent == null) {
			n.parent = rchild; 
		}
		//If it's to the left of parent
		else if (n == n.parent.left) {
			n.parent.left = rchild;

		}
		else { //If it's to the right
			n.parent.right = rchild; 

		}

		if (rchild != null) {
			rchild.left = n; 
		}
		n.parent = rchild; 

	}


	public void insert(String s) {

		if (root == null) {
			root = new SPLT_Node(s);
			size++;
			return; 
		}

		if (s == root.data) {
			size--; 
		}

		SPLT_Node n = root.insertNode(s); 
		if (n.data == root.containsNode(s).data) { 
			size++; 
		}

		splay(n);

		root = n; 


	}

	public void remove(String s) {
		if (root == null) {
			return; 
		}
		contains(s);
		if (root.data == s) {
			SPLT_Node leftTree = root.left; 
			SPLT_Node rightTree = root.right; 
			size--; 

			if (rightTree != null) {
				rightTree.parent = null; 
			}

			if (leftTree != null) {
				leftTree.parent = null; 
			}

			if(leftTree != null){
				leftTree = leftTree.findMax(); 
				leftTree.right = rightTree; 
				root = leftTree; 
				leftTree.parent = null;  
			}
			else{
				root = rightTree; 
			}
		}
	}


	public String findMin() {
		splay(root.findMin());
		return root.data;
	}

	public String findMax() {
		splay(root.findMax());
		return root.findMax().data; 
	}

	public boolean empty() {
		if (size == 0) {
			return true; 
		}
		else { return false; }
	}

	public boolean contains(String s) {

		if (root == null) {
			return false; 
		}

		SPLT_Node found = root.containsNode(s);

		splay(found);

		if (root.data == s) {
			root = root.containsNode(s);
			return true; 
		}
		root = root.containsNode(s);
		return false; 
	}

	public int size() {
		return size; 
	}

	public int height() {
		return root.getHeight(); 
	}
}
