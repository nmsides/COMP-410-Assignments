package SPLT_A4;

public class SPLT_Node {
	String data;
	SPLT_Node left;
	SPLT_Node right;
	SPLT_Node parent;

	SPLT_Node(String data){ this.data=data; }

	public String getData(){ 
		return data; 
	}
	public SPLT_Node getLeft(){ 
		return left;
	}
	public SPLT_Node getRight(){
		return right;
	}

	public SPLT_Node containsNode(String s){

		SPLT_Node temp; 
		int delt = s.compareTo(data);

		if(delt < 0) {
			if (left == null) {
				return this; 
			}
			temp = left; 
			return left.containsNode(s);
		}
		else if (delt > 0) {
			if (right == null) {
				return this; 
			}
			temp = right; 
			return right.containsNode(s);
		}
		else {
			return this; 
		}
	}



	public SPLT_Node insertNode(String s){ 
		SPLT_Node b = new SPLT_Node(s); 
		if (s.compareTo(this.data) == 0) {
			return this;
		}
		else if (s.compareTo(this.data) < 0) {
			if (this.left == null) {
				this.left = b;
				left.parent = this;
				return b; 
			}
			else {
				return this.left.insertNode(s);
			}
		}
		else if (s.compareTo(this.data) > 0) {
			if (this.right == null) {
				this.right = b;
				right.parent = this; 
				return b; 
			}
			else {
				return this.right.insertNode(s);
			}
		}
		return b; 
	}


	public boolean removeNode(String s){ 

		if (data.compareTo(s) < 0) {
			if (right == null) {
				return false; 
			}
			return right.removeNode(s);
		}
		if (data.compareTo(s) > 0) {
			if (left == null) {
				return false; 
			}
			return left.removeNode(s);
		}
		else {
			//If it is a leaf 
			if (left == null && right == null) {
				if (this.data.compareTo(parent.data) < 0) {
					parent.left = null;
					return true;
				}
				if (this.data.compareTo(parent.data) > 0) {
					parent.right = null;
					return true; 
				}
			}

			//If this has left child but not right
			if (left != null && right == null) {
				String temp = left.findMax().data; 
				left.removeNode(temp);
				data = temp; 
				return true; 
			}

			//If this has right child but not left
			else {
				String temp = right.findMin().data; 
				right.removeNode(temp);
				data = temp; 
				return true; 
			}
		}
	} 


	public SPLT_Node findMin(){ 
		SPLT_Node n = this; 
		if (n.left == null) {
			return n; 
		}
		return n.left.findMin(); 
	}


	public SPLT_Node findMax(){ 
		SPLT_Node n = this; 
		if (n.right == null) {
			return n; 
		}
		return n.right.findMax(); 
	}


	public int getHeight(){ 
		int l=0;
		int r=0;
		if(left!=null)l+=left.getHeight()+1;
		if(right!=null)r+=right.getHeight()+1;
		return Integer.max(l, r);
	}


	// --- end fill in these methods --------------------------------------


	// --------------------------------------------------------------------
	// you may add any other methods you want to get the job done
	// --------------------------------------------------------------------

	public String toString(){
		return "Data: "+this.data+", Left: "+((this.left!=null)?left.data:"null")
				+",Right: "+((this.right!=null)?right.data:"null") +",Parent: "+((this.parent!=null)?parent.data:"null");
	}


}
