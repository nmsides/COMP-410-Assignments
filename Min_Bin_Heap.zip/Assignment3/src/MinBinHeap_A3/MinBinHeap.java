package MinBinHeap_A3;

public class MinBinHeap implements Heap_Interface {
	private EntryPair[] array; //load this array
	private int size=0;
	private String value;
	private int priority;
	private static final int arraySize = 10000; //Everything in the array will initially 
	//be null. This is ok! Just build out 
	//from array[1]

	public MinBinHeap() {
		this.array = new EntryPair[arraySize];
		array[0] = new EntryPair(null, -100000); //0th will be unused for simplicity 
		//of child/parent computations...
		//the book/animation page both do this.
	}

	//Please do not remove or modify this method! Used to test your entire Heap.
	@Override
	public EntryPair[] getHeap() { 
		return this.array;
	}

	@Override
	public void insert(EntryPair entry) {
		if(size == 0){
			array[1] = entry;
			size++;
		}else{
			int x = (size+1)/2;
			EntryPair temp = null;
			array[size+1] = entry;
			int n = size +1;
			while(entry.getPriority() < array[x].getPriority()){
				temp  = array[x];
				array[x] = entry;
				array[n] = temp;
				n = x;
				x = x/2;
			}
			size++;
		}
	}

	@Override
	public void delMin() {
		if(size ==0)return;
		array[1] = array[size];
		array[size] = null;
		size--;
		int curr = 1;
		while(array[curr*2] != null){
			if(array[curr*2+1] == null){
				if(array[curr].getPriority() > array[curr*2].getPriority()){
					EntryPair p = null;
					p = array[curr];
					array[curr] = array[curr*2];
					array[curr*2] = p;
				}
				curr = curr*2;
			}else{
				if(array[curr*2].getPriority() < array[curr*2+1].getPriority()){
					if(array[curr*2].getPriority() < array[curr].getPriority()){
						EntryPair p = null;
						p = array[curr];
						array[curr] = array[curr*2];
						array[curr*2] = p;
						curr = curr*2;
					}
				}else{
					if(array[curr*2].getPriority() > array[curr*2+1].getPriority()){	
						if(array[curr*2+1].getPriority() < array[curr].getPriority()){
							EntryPair p = null;
							p = array[curr];
							array[curr] = array[curr*2+1];
							array[curr*2+1] = p;
							curr = curr*2+1;
						}
					}
				}
			}
		}
	}

	@Override
	public EntryPair getMin() {
		if(array[1] == null) return null;
		return array[1];
	}

	@Override
	public int size() {
		if(array == null) return 0;
		return size;
	}

	@Override
	public void build(EntryPair[] entries) {
		int i = 1;
		for(EntryPair x: entries){
			priority = x.priority;
			value = x.value;
			array[i] = x;
			i++;
		}
		size = entries.length;
		int parent = (size/2);
		while(parent >=1){
			bubble(parent);
			parent--;
		}
	}
	private void bubble(int parent) {

		while (parent * 2 <= size) {
			//If it has only left child
			if (parent*2 == size) {
				if (array[parent].priority > array[parent*2].getPriority()) {
					EntryPair temp = array[parent*2]; 
					array[parent*2] = array[parent];
					array[parent] = temp;
				}
				else {
					parent = parent*2; 
				}
			}
			else {
				if (array[parent*2].getPriority() < array[parent].getPriority()
						|| array[parent*2 + 1].getPriority() < array[parent].getPriority()) {
					if (array[parent*2].priority > array[parent*2 + 1].priority) {
						EntryPair temp = array[parent*2+1];
						array[parent*2+1] = array[parent];
						array[parent] = temp; 
						//Move cursor to right child 
						parent = parent*2+1; 
					}
					else {
						EntryPair temp = array[parent*2];
						array[parent*2] = array[parent];
						array[parent] = temp; 
						//move cursor to left child 
						parent = parent*2; 
					}
				}
				else {
					parent = parent*2; 
				}
			}
		}
	}
}