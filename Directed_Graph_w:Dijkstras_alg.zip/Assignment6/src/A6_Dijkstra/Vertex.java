package A6_Dijkstra;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class Vertex {

	 String label;

	 long id;
	 int inEdges;
	 HashSet<String> outEdgeList;
	 HashSet<String> inEdgesList;
	 long distance;
	 boolean known;
	 
	
	public Vertex(Long idnum, String Label){
		distance = Long.MAX_VALUE;
		known = false;
		label = Label;
		id = idnum;
		
		
		outEdgeList = new HashSet<String>();
		inEdgesList = new HashSet<String>();
	}
	
	public String getLabel(){
		return label;
	}
	
	public Long getIDnum(){
		return id;
	}
	
}
