package A6_Dijkstra;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;


public class DiGraph implements DiGraph_Interface {

	ConcurrentHashMap<String, Vertex> map = new ConcurrentHashMap<String, Vertex>();
	HashSet<Long> vertSet = new HashSet<Long>();
	ConcurrentHashMap<Long, Edge> edgeSet = new ConcurrentHashMap<Long, Edge>();


	// in here go all your data and methods for the graph
	// and the topo sort operation

	public DiGraph ( ) { // default constructor
		// explicitly include this
		// we need to have the default constructor
		// if you then write others, this one will still be there
	}

	@Override
	public boolean addNode(long idNum, String label) {
		if(idNum < 0){
			return false;
		}else{
			Vertex v = new Vertex(idNum, label);
			if(map.keySet().contains(label) || vertSet.contains(idNum)){
				return false;
			}
			vertSet.add(idNum);
			map.put(label, v);
			return true;
		}
	}

	@Override
	public boolean addEdge(long idNum, String sLabel, String dLabel, long weight, String eLabel) {


		if(idNum < 0){
			return false;
		}
		Edge e = new Edge(idNum, sLabel, dLabel, weight);


		if(edgeSet.keySet().contains(idNum)){
			return false;
		}

		if(map.keySet().contains(sLabel) && map.keySet().contains(dLabel)){
			if(map.get(sLabel).outEdgeList.contains(dLabel)){
				return false;
			}
			map.get(sLabel).outEdgeList.add(dLabel);
			map.get(dLabel).inEdgesList.add(sLabel);
		}else{
			return false;
		}

		edgeSet.put(idNum, e);
		return true;
	}


	@Override
	public boolean delNode(String label) {
		Boolean b = false;

		if(map.keySet().contains(label)){
			for(String s : map.get(label).outEdgeList){
				map.get(s).inEdgesList.remove(label);

			}
			b = true;
		}

		if(b){
			vertSet.remove(map.get(label).id);
			map.remove(label);
		}
		return b;
	}

	@Override
	public boolean delEdge(String sLabel, String dLabel) {
		Boolean b = false;
		Edge edg = null;		

		if(map.keySet().contains(sLabel) && map.keySet().contains(dLabel)){
			if(map.get(sLabel).outEdgeList.contains(dLabel) && map.get(dLabel).inEdgesList.contains(sLabel)){
				map.get(sLabel).outEdgeList.remove(dLabel);
				map.get(dLabel).inEdgesList.remove(sLabel);

				b = true;
			}
		}

		if(b){
			for(Edge ed : edgeSet.values()){
				if (ed.slabel == sLabel && ed.dlabel == dLabel){
					edg = ed;
				}
			}
			edgeSet.remove(edg.id);
		}

		return b;
	}

	@Override
	public long numNodes() {

		return vertSet.size();
	}

	@Override
	public long numEdges() {

		return edgeSet.size();
	}

	@Override
	public String[] topoSort() {
		String[] topoSortArray = new String[vertSet.size()];
		Deque<Vertex> q = new ArrayDeque<Vertex>();
		int x = 0;
		HashSet<String> out = new HashSet<String>();
		for(String s : map.keySet()){
			if(map.get(s).inEdgesList.size() == 0){
				q.add(map.get(s));
			}

		}

		while(!map.isEmpty()){
			if(q.isEmpty()){
				topoSortArray = null;
				break;
			}
			while (!q.isEmpty()){

				topoSortArray[x] = q.getFirst().label;
				out = map.get(topoSortArray[x]).outEdgeList;
				this.delNode(topoSortArray[x]);
				x++;
				q.removeFirst();
				for(String s : out){
					if(map.get(s).inEdgesList.size() == 0){
						q.add(map.get(s));
					}
				}

			}

		}
		return topoSortArray;
	}

	@Override
	public ShortestPathInfo[] shortestPath(String label) {
		ShortestPathInfo[] returnArray = new ShortestPathInfo[(int) this.numNodes()];
		MinBinHeap heap = new MinBinHeap();
		HashSet<Long> newVerts = new HashSet<Long>();
		int i = 0;
		Vertex n = null;

		long d = map.get(label).distance;
		d = 0;
		heap.insert(new EntryPair(label, (int) d));

		while(heap.size() != 0){
			n = map.get(heap.getMin().value);
			d = heap.getMin().distance;

			heap.delMin();

				if(n.known == false){
					n.known = true;
					int edgeWeight = 0;
					for(String b : map.get(n.label).outEdgeList){
						for(Edge e : edgeSet.values()){
							if(e.slabel == n.label && e.dlabel == b){
								edgeWeight = (int) e.weight;
							}
						}
						if(map.get(b).distance > edgeWeight + d){
							map.get(b).distance = edgeWeight + d;
							heap.insert(new EntryPair(b, (int) (edgeWeight + d)));
						}
					}
					returnArray[i] = (new ShortestPathInfo(n.label, d));
					newVerts.add(n.id);
					i++;
				}
			}
		for(long q : vertSet){
			if(!newVerts.contains(q)){
				returnArray[i] = (new ShortestPathInfo(n.label, d));
				i++;
			}
		}
		return returnArray;
	}

	// rest of your code to implement the various operations
}